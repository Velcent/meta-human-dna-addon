SPAN_ORIGIN = "auto.ai.openai_agents"
